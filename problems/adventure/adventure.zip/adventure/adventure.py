import room, item

def loadRooms(filename):
    """
    load rooms from filename
    returns a list of Room objects
    """
    with open(filename, "r") as f:
        # TODO
        pass

def loadItems(filename):
    """
    load items from filename
    returns a list of Item objects
    """
    with open(filename, "r") as f:
        # TODO
        pass

def play(game):
    """
    Play an Adventure game
    """
    rooms = loadRooms(f"data/{game}Rooms.txt")
    # items = loadItems(f"data/{game}Items.txt")

    # TODO

if __name__ == "__main__":
    game = "Tiny"
    # stap 1
    # print("stap 1")
    # rooms = loadRooms("TinyRooms.txt")
    # for room in rooms:
    #     print(room)

    # stap 2
    # print("stap 2")
    # rooms = loadRooms("TinyRooms.txt")
    # print(rooms[0].move("WEST")) # should print room 2: End of road
    # print(rooms[0].move("IN")) # should print room 3: Inside building
    # print(rooms[0].move("WEST").move("EAST")) # should print room 1: Outside building
    # print(rooms[0].move("OUT")) # should print: None

    pass

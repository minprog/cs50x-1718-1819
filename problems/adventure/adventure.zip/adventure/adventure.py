from room import Room

class Adventure():
    """
    This is your Adventure game class. It should contains
    necessary attributes and methods to setup and play
    Crowther's text based RPG Adventure.
    """
    def __init__(self, game):
        """
        Create rooms and items for the appropriate 'game' version.
        """
        self.rooms = self.load_rooms(f"data/{game}Rooms.txt")

    def load_rooms(self, filename):
        """
        Load rooms from filename.
        Returns a collection of Room objects.
        """
        with open(filename, "r") as f:
            # TODO: Parse the rooms data file and create rooms.
            pass

    def won(self):
        """
        Check if the game is won.
        Returns a boolean.
        """
        # TODO: Define the win condition for Adventure.
        return False

    def move(self, direction):
        """
        Moves to a different room in the specified direction.
        """
        # TODO: Update the current room to a connected direction.
        pass

    def play(self):
        """
        Play an Adventure game
        """
        print(f"Welcome, to the Adventure games.\n"
            "May the randomly generated numbers be ever in your favour.\n")

        # Prompt the user for commands until they've won the game.
        while not won():
            command = input("> ")
            # Check if the command is a movement or not.
            if command in ["east", "west", "in", "out"]:
                # TODO: Perform a move.
                pass
            else:
                # TODO: Command not implemented!
                pass

if __name__ == "__main__":
    adventure = Adventure("Tiny")

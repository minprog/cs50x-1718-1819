class Item(object):
    """
    Representation of an Item in Adventure
    """

    def __init__(self, name, description):
        """
        Initialize an Item
        give it a name and description
        """
        # TODO
        pass

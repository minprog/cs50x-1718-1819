class Room(object):
    """
    Representation of a room in Adventure
    """

    def __init__(self, id, name, description):
        """
        Initializes a Room
        """
        self.id = id
        self.name = name
        self.description = description

    def add_route(self, direction, room):
        """
        Adds a given direction and the connected room to our room object.
        """
        # TODO: implement (hint: you might need to add some lines to init)
        pass

    def is_connected(self, direction):
        """
        Checks whether the given direction has a connection from a room.
        Returns a boolean.
        """
        # TODO: implement
        return False

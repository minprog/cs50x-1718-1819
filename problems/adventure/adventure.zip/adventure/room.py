class Room(object):
    """
    Representation of a room in Adventure
    """

    def __init__(self, id, name, description):
        """
        Initialize a Room
        give it an id, name and description
        """
        # TODO
        pass

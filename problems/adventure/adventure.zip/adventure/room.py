class Room(object):
    """
    Representation of a room in Adventure
    """

    def __init__(self, id, name, description):
        """
        Initialize a Room
        give it an id, name and description
        """
        # TODO
        pass

    def move(self, command):
        """
        Go to the next room based on command
        Takes in a text based command, i.e. WEST or IN or EAST
        Returns the room (a Room object) connected to said command
        Returns None if the command does not exist
        """
        # TODO
        pass

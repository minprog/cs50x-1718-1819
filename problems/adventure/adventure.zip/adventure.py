import player, room

def loadRooms(filename):
    """
    load rooms from filename
    returns a list of Room objects
    """
    with open(filename, "r") as f:
        # TODO
        pass

def loadItems(filename):
    """
    load items from filename
    returns a list of Item objects
    """
    with open(filename, "r") as f:
        # TODO
        pass

def won():
    """
    Check if the player has won the game.
    Returns the appropriate Boolean.
    """
    return False

def play(game):
    """
    Play an Adventure game
    """
    rooms = loadRooms(f"data/{game}Rooms.txt")

    player_1 = player.Player(42, "Player 1", None)
    print(f"Welcome, {player_1.name}, to the Adventure games.\n"
        "May the randomly generated numbers be ever in your favour.\n")

    # A collection of valid commands to be used in the player.move method.
    moves = set(["east", "west", "in", "out"])

    while not won():
        command = input("> ")
        if command in moves:
            # TODO: Perform a move.
            pass
        else:
            # TODO: Command not implemented!
            pass


if __name__ == "__main__":
    game = "Tiny"
    play(game)

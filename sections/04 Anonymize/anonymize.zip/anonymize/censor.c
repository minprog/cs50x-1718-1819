/**
 * Implements the change image functionality.
 */
 
#include "censor.h"
 
/**
 * Processes a given pixel (triple) and return the new one.
 */
RGBTRIPLE process_pixel(RGBTRIPLE old_triple, int y, int x)
{
    RGBTRIPLE new_triple = old_triple;
    
    // TODO: change new_triple if necessary
    
    return new_triple;
}
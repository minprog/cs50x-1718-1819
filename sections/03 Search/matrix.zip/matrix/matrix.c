#include <stdio.h>
#include <cs50.h>

#define MATRIX_DIMENSIONX 3
#define MATRIX_DIMENSIONY 5

void set_to_zero(int array[MATRIX_DIMENSION_X][MATRIX_DIMENSION_Y], int limit);

int main(void)
{
    // defining a 2D array with dimensions X and Y
    int matrix[MATRIX_DIMENSION_X][MATRIX_DIMENSION_Y] = {{}};

    // fills X by Y matrix with numbers ranging from 0 to X * Y
    for (int i = 0; i < MATRIX_DIMENSION_X; i++)
    {
        for (int j = 0; j < MATRIX_DIMENSION_Y; j++)
        {
            matrix[i][j] = j + i * MATRIX_DIMENSION_X;
        }
    }

    // asks user for the limit, all numbers below will be set to 0
    printf("What should the limit be? ");
    int limit = get_int();

    set_to_zero(matrix, limit);

    // prints array
    for (int i = 0; i < MATRIX_DIMENSION_Y; i++)
    {
        for (int j = 0; j < MATRIX_DIMENSION_X; j++)
        {
            printf("%i\n", matrix[i][j]);
        }
    }
}

/* Sets all elements of an integer array to zero, if they are below the limit. */
void set_to_zero(int array[MATRIX_DIMENSION_X][MATRIX_DIMENSION_Y], int limit)
{
    for (int i = 0; i < MATRIX_DIMENSION_X; i++)
    {
        for (int j = 0; j < MATRIX_DIMENSION_Y; j++)
        {
            if (array[i][j] < limit)
            {
                array[i][j] = 0;
            }
        }
    }
}
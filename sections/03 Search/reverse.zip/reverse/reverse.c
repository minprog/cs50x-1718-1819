/**
 * Prompts user for as many as MAX values until EOF is reached
 * and accumulates those values in an array, then reverses that array.
 *
 * Usage: ./reverse
 */

#include <stdio.h>
#include <cs50.h>

void reverse(int array[], int size);
void print_array(int array[], int size);

// maximum number of elements
const int MAX = 65536;

int main()
{
    // fill array
    int size;
    int array[MAX];
    for (size = 0; size < MAX; size++)
    {
        // wait for hay until EOF
        printf("\nelement[%i] = ", size);
        int element = get_int();
        if (element == INT_MAX)
        {
            break;
        }

        // add element to array
        array[size] = element;
    }
    printf("\n");

    // show array
    printf("Input: ");
    print_array(array, size);

    // show reversed array
    reverse(array, size);
    printf("Reversed list: ");
    print_array(array, size);
}

void reverse(int *array, int size)
{
    for(int i = 0; i < sizeof(array)/sizeof(int); i++)
    {
        // swap values
        int tmp = array[i];
        array[i] = array[size - i - 1];
        array[size - i - 1] = tmp;
    }
}

void print_array(int *array, int size)
{
    printf("[");
    // check is list not empty
    if(size > 0)
    {
        // print all but last values with a comma
        for(int i = 0; i < size - 1; i++)
        {
            printf("%d, ", array[i]);
        }
        // print last value with a comma
        printf("%d", array[size - 1]);
    }
    printf("]\n");
}
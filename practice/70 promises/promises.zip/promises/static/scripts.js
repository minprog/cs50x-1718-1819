/* on load:
 */
$(function() {
    // Set default text in data fields
    $("#data1").html("This is where the slow data will appear.");
    $("#data2").html("This is where the fast data will appear.");
});

/* Slow: called by slow-button in index.html
 */
function slow()
{
    var data = loadData("/slow");
    $("#data1").html(data["data"]);
}

/* Fast: called by fast-button in index.html
 */
function fast()
{
    var data = loadData("/fast")
    $("#data2").html(data["data"]);
}


/* loadData: This is _not_ how you write a good load function. Don't
 * do this at home!
 * The function reads JSON data from url and returns the data once
 * it is loaded.
 */
function loadData(url)
{
    xmlhttp=new XMLHttpRequest();
    xmlhttp.open("GET", url, false);
    xmlhttp.send();
    return JSON.parse(xmlhttp.responseText);
}
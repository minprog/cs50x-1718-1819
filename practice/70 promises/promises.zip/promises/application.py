###################################################################
# Practice exercise, promises.
# This creates a small webserver that provides some practice
# with promises.
###################################################################

from flask import Flask, render_template, request, url_for, jsonify
from flask_session import Session
from passlib.apps import custom_app_context as pwd_context
from tempfile import mkdtemp
import time

# configure application
app = Flask(__name__)

# ensure responses aren't cached
if app.config["DEBUG"]:
    @app.after_request
    def after_request(response):
        response.headers["Cache-Control"] = "no-cache, no-store, must-revalidate"
        response.headers["Expires"] = 0
        response.headers["Pragma"] = "no-cache"
        return response

# main route: show index.html
@app.route("/")
def index():
    return render_template("index.html");

# Slow: delay 3 seconds and then send a json
@app.route("/slow")
def slow():
    time.sleep(3);
    return jsonify({"data": "This route is slow."});

# Fast: delay 1 seconds and then send a json
@app.route("/fast")
def fast():
    time.sleep(1);
    return jsonify({"data": "This route is fast."});
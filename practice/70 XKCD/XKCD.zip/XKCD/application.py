from flask import Flask, jsonify, render_template, request
import requests
import json

# configure application
app = Flask(__name__)

# main route: show index.html
@app.route("/", methods=["GET", "POST"])
def index():
    if request.method == "POST":
        comicNumber = 1
        return render_template("index.html", comic=getXKCD(comicNumber))
    else:
        return render_template("index.html", comic=getXKCD(1144))

# getXKCD, retrieves a comic from the XKCD website and returns a JSON with the comic information
def getXKCD(id):
    uri = "https://xkcd.com/{}/info.0.json".format(id)
    try:
        uResponse = requests.get(uri)
    except requests.ConnectionError:
       return "Connection Error"
    Jresponse = uResponse.text
    comicJSON = (json.loads(Jresponse))
    return comicJSON

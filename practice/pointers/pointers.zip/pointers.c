#include <stdio.h>

int main()
{
	char* s = "Star Lord";

  // TODO 1 assign the adress
	char* point;

  printf("%c", point);

  // TODO 2 change point with 5

  // TODO 3 print the string point

  // TODO 4 print the character point
}

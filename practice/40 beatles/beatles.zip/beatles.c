#include <stdio.h>

typedef struct {
    char* name;
    char* instrument;
    int year_born;
} musician;

int main()
{
    // Step 1: Greate a 'john' variable
    // Step 2: Set the fields to the appropriate values

    // Step 4: Call the print function on 'john'

}


// Step 3: create a print function